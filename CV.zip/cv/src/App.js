
import './App.css';
import Academy from './components/academy';
import Certificate from './components/certificate';
import Labor  from './components/labor';
import PersonalData from './components/personalData';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>
          RESUME
        </h1>
        <PersonalData></PersonalData>
        <Academy></Academy>
        <Labor></Labor>
        <Certificate></Certificate>
        <PersonalData></PersonalData>
      </header>
    </div>
  );
}

export default App;
