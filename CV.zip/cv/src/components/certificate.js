import React from 'react';


function Certificate(){

    
    return(
        <>
            <h2 className= 'certificate-record'>Certificate RECORD</h2>
                <ul className= 'certificate-list'>
                    <li>Credit analysis for SMEs, instructed by David Gutierrez Brena, Chief Risk Officer for SME of BBVA with 
                    collaboration of Risk Mathics(2021)
                    </li>
                    <li>Credit analysis for SMEs, instructed by David Gutierrez Brena, Chief Risk Officer for SME of BBVA with 
                    collaboration of Risk Mathics(2021)
                    </li>
                    <li>Google IT Support Professional Certificate</li>
                    <li> Facebook Certified Digital Marketing Associate</li>
                    <li>Learn Data Analysis with Pandas Course Analyze Financial Data with Python Skill Path</li>
                </ul>
        </>
    )

}

export default Certificate;