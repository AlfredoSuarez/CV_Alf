import React from 'react';


function PersonalData(){

    
    return(
        <div className= 'personal-data-record'>
            <ul className= 'personal-data-list'>
                <img src='./img/personal-pic' alt='alfred-picture'/>
                <li>Alfredo Ricardo Suarez Espinosa</li>
                <li>e-mail.- arse.alf@gmail.com, mobile.- +52 56 19880108</li>
                <a href='https://www.linkedin.com/in/alfredo-ricardo-su%C3%A1rez-espinosaab914624/'><li><img src='https://www.mundocuentas.com/wp-content/uploads/2020/11/Linkedin-logo-mundocuentas.jpg' alt='linkedin profile'/></li></a>
                <a href='Github: https://github.com/AlfredoSuarez'><li><img src='https://blog.digital-pineapple.com.mx/wp-content/uploads/2021/06/GitHub_aprender-programacion.jpg' alt='github portfolio'/></li></a>
                <li>Financial managment</li>
                </ul>
        </div>
    )

}

export default PersonalData;