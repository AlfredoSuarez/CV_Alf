import React from 'react';


function Labor(){

    
    return(
        <>
            <h2 className= 'labor-record'>Labor RECORD</h2>
                <ul className= 'labor-list'>
                    <li>Co-founder of EZ-FOOD (Present), which is a responsive app for digitize and automate restaurant process on 
                    site and retail.</li>
                    <li>Co-founder of www.2dine.io (2017-2020 ) . A platform that helps retail industry with AI(specially restaurants), 
                    to enhance customer service, labor and logistics with AI. Also with collaboration with UBTECH we created an 
                    R&D project, where robots make customer first contact experience
                    <a href='https://drive.google.com/file/d/1qxmCtf_wIoxRzIYjhfnHFxgTxQIcrpaY/view?usp=sharing'>
                        <img src='https://http2.mlstatic.com/D_NQ_NP_634539-MLM44340364940_122020-O.jpg' alt='ubtech-cruzr-robot'/>
                    </a>
                    </li>
                    <li>The Beach Taste LLC (2015-2020), Pompano Beach, Florida, as Manager / Marketing / R&D AI project manager
                    (combining Cloud Platforms and AI to take orders/payments and customer service with UBTECH Company
                    (business partner);<a href='https://drive.google.com/file/d/1t8HfcNL2rghX0kVwQxFfzBn0BbYwVKeS/view?usp=sharing'><img src='https://images.samsung.com/is/image/samsung/mx-galaxy-tab-a-t290-sm-t290nzkamxo-frontblack-177815134?$720_576_PNG$' alt='samsung-tablet'/></a>
                    </li>
                    <li>Credit Analyst of Citi Group Mexico (Citibanamex-2014-2015), in Business Banking, taking responsibility to give 
                    credit to Small and Medium Enterprises (from working capital to infrastructure acquisition), doing financial 
                    analysis for business development; restructuring debt with alternative collaterals or methods of payments, 
                    even providing credit in foreign currency, may include hedge position through derivatives.
                    </li>
                    <li>Gestion y Asesoria Empresarial Integral (2011-2014) as financial analyst for SME´s, promoting credit solutions 
                    and financial consulting case by case, according each industry involved and goals of each company, including 
                    auditing financial statements (due diligence process), for international transactions (international contracts 
                    between Mexican and foreign companies, for example mining companies.</li>
                </ul>
        </>
    )

}

export default Labor;