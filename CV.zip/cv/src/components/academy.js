import React from 'react';

function Academy(){

    
    return(
        <>
            <h2 className= 'academy-record'>ACADEMY RECORD</h2>
                <ul className= 'academy-list'>
                    <li>August 2008-May2013.- College: Financial Management at ITESM-CCM (Mexico City, Mexico)</li>
                    <li>January 2012 – June 2012.- HESSO (Haute École Spécialisée de Suisse Occidentale-Haute Ecole de 
                    Gestion) Certificate on Banking and Insurance
                    </li>
                    <li>May 2013.- AMIB’s (Asociación Mexicana de Intermediarios Bursátiles, spanish); Type III certificate (By 
                    law, provides investment guidance as a financial entity</li>
                    <li>Master in code: Dev.F May 2021-May 2022</li>
                    <li>Coding programs-May 2017- present: Codecademy/Coursera/Google/IBM/Facebook: Data Science, 
                    Machine Learning, Deep Learning; Html, CSS, JavaScript, Python</li>
                </ul>
        </>
    )

}

export default Academy;

